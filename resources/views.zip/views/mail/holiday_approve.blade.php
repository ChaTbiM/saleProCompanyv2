<h1>Congratulation {{$name}}!</h1>
<h3>Your requested holiday has just approved.</h3>
<p>Thank you</p>